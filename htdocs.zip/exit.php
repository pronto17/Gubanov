<?php
setcookie('user', $user['pass'], time() - 3600, "/");
header('Location: index.php');
?>