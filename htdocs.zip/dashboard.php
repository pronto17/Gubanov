<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		table {
			border: 1px solid grey;
			border-collapse: collapse;
		}
		td {
   border: 1px solid grey;
}
		tr {
   border: 1px solid grey;
}
	</style>
</head>
<body>
	<div class="container mt-4">
	<h1>Email address</h1>
	<form action="bruh.php" method="post">
<input type="text" name="mail" placeholder="name@example.com">
	<h1>Full name</h1>
<input type="text" name="name" placeholder="Deniss Gubanov">
<h1>Category</h1>
<select class="form-select" name="category" aria-label="Default select example">
  <option value="1">Option 1</option>
  <option value="2">Option 2</option>
  <option value="3">Option 3</option>
</select>
	<h1>Note</h1>
<input type="text" name="note" placeholder="Text note"></br>
<button class="btn btn-primary" type="submit">Submit</button></br>
<table>
	<tr>
		<td>ID</td>
		<td>Name</td>
		<td>Email</td>
		<td>Category</td>
		<td>Note</td>
	</tr>
	<tr>
		<td>
			
   
 
		</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
</table>
<p><a href="/exit.php">mmm</a></p>
</div>
</body>
</html>