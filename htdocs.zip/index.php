<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Форма регистрации</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
</head>
<body>
	<div class="container mt-4">
		<?php 
		if ($_COOKIE['user'] == ''):
			
		?>

		<h1>Форма регистрации</h1>
		<form action="validation-form/auth.php" method="post">
		<input type="password" class="form-control" name="pass" id="pass" placeholder="Password"></br>
		<button class="btn btn-success" type="submit">Button</button>
	</form>
    <?php else: ?>
<?php 
header('Location: dashboard.php');
?>
	<?php endif;?>
	</div>

</body>
</html>