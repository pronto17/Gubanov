<?php 
 $pass = filter_var(trim($_POST['pass']),
FILTER_SANITIZE_STRING);
 $mail = filter_var(trim($_POST['mail']),
FILTER_SANITIZE_STRING);
 $name = filter_var(trim($_POST['name']),
FILTER_SANITIZE_STRING);
 $category = filter_var(trim($_POST['category']),
FILTER_SANITIZE_NUMBER_INT);
 $note = filter_var(trim($_POST['note']),
FILTER_SANITIZE_STRING);

if (mb_strlen($mail) <= 0) {
    echo "Ошибка1";
    exit();
}
else if (mb_strlen($name) <= 0) {
    echo "Ошибка2";
    exit();
}
else if (mb_strlen($note) <= 0) {
    echo "Ошибка3";
    exit();
}

$pass = md5($pass."bruh");

$mysql = new mysqli('localhost','root','','register-bd'); 
 $result = $mysql->query("SELECT * FROM `users` WHERE `pass` = '$pass'");
 $mysql->query("INSERT INTO `users2` (`mail`, `name`, `category`, `note`) VALUES('$mail','$name','$category','$note')");
 $user = $result->fetch_assoc();

setcookie('user', $user['pass'], time() + 3600, "/");

$mysql->close();

header('Location: /');
?>