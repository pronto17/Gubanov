<?php 
 $pass = filter_var(trim($_POST['pass']),
FILTER_SANITIZE_STRING);

$pass = md5($pass."bruh");

$mysql = new mysqli('localhost','root','','register-bd'); 
 $result = $mysql->query("SELECT * FROM `users` WHERE `pass` = '$pass'");
 $user = $result->fetch_assoc();

setcookie('user', $user['pass'], time() + 3600, "/");

$mysql->close();

header('Location: /');
?>